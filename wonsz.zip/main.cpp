#include <iostream>
#include <conio.h>
#include <cstdlib> //system CLS
#include <time.h> //randomizacja
#include <windows.h> //sleep
#include <fstream>
using namespace std;
int a;
int width = 10;
int height = 20;
char borderV=186, borderH=205;
char cornerRU=187, cornerLU=201, cornerRD=188,cornerLD=200;
int up, down;
int key;
int speed;
int snakeX, snakeY;
char snake=219;
int foodX, foodY;
char food=176;
int leng=3;
int snakeXhistory[10000], snakeYhistory[10000];
int moves=0;
char direct='r';
char tab[10][20]; //plansza


void historyScore(){                                    //historia gry
    system("cls");
    cout<<"To get back to the welcome screen, press W\n\nThese are your recent scores:\n";

    string line;

    fstream history("plik.txt", ios::in);

    if(history.good() == true)
    {
        while(!history.eof())
        {
            getline(history, line);
            cout << line << "\n"; //wyświetlenie linii
        }
       history.close();
    }


    a=getch();
    if(a==104  || a==72){historyScore();}
	if(a==119  || a==87){
	    system("cls");
        cout<<"\n\n\n\n\n\n\n\n\n                                                     Wonsz. the Game.\n\n";
        cout<<"                                          You're about to play an amazing game!\n";
        cout<<"                                                 Press H to open history,\n";
        cout<<"                                               any other key to start game\n";
        a=getch();
        if(a==104  || a==72){
		historyScore();
	}
	else if(a!=119  || a!=87){system("cls");};
	}
	}



void welcome(){                                 //ekran poczatkowy
	system("cls");
	cout<<"\n\n\n\n\n\n\n\n\n                                                    Wonsz. the Game.\n\n";
	cout<<"                                           You're about to play an amazing game!\n";
	cout<<"                                                 Press H to open history,\n";
	cout<<"                                               any other key to start game\n";
	a=getch();
	if(a==104  || a==72){
		historyScore();
	}
	else if(a!=104  || a!=72){system("cls");}
	;
}



void fast(){
    if (speed<1)speed=1;
    if (speed>10)speed=10;}

void foodXY (){                                 //losowanie polozenia jedzenia
    do{
    foodX=rand()%width;
    foodY=rand()%height;
    }while(tab[foodX][foodY] != 'v');

    tab[foodX][foodY]='f';
    }

void board(){
            cout<<cornerLU;
            for (int i=0; i<width; i++){
                cout<<borderH<<borderH;
            }
            cout<<cornerRU;
            for (int i=0; i<height; i++){
                cout<< "\n"<<borderV;
                for (int j=0;j<width;j++){
                    if(tab[j][i]=='v')cout<<"  ";
                    if(tab[j][i]=='s')cout<<snake<<snake;
                    if(tab[j][i]=='f')cout<<food<<food;
                       }
                cout<< borderV;
            }
            cout<<"\n";
            cout<<cornerLD;
            for (int i=0; i<width; i++){
                cout<<borderH<<borderH;
            }
            cout<<cornerRD;}


void wall(){                                    //umozliwia przejscie przez sciane
        if(snakeX==width) snakeX=0;
        if(snakeX==-1) snakeX=width-1;
        if(snakeY==height) snakeY=0;
        if(snakeY==-1) snakeY=height-1;}



int main(){

    welcome();

    cout << "How fast do you want to go? Pick a number from 1 to 10:\n";
    cin>> speed;
    fast();

    cout<< "Pick the keys you want to use:\n";
                                                                //wybor klawiszy
    cout << "up:   ";
    up=getch();
    if (up == 224) up = up+getch();
    if (up == 0) up = up-getch();

    cout << "down:   ";
    down=getch();
    if (down == 224) down = down+getch();
    if (down == 0) down = down-getch();

    cout << "left:   ";
    int left=getch();
    if (left == 224) left = left+getch();
    if (left == 0) left = left-getch();

    cout << "right:   ";
    int right=getch();
    if (right == 224) right = right+getch();
    if (right == 0) right = right-getch();

    for(int i=0;i<height;i++)
    {
        for (int j=0;j<width;j++){
            tab[j][i]='v';
        }
    }

    srand(time(NULL));

    snakeX=rand()%width;
    snakeY=rand()%height;
    tab[snakeX][snakeY]='s';


    foodXY();

    //gra!
    for(;;){
        moves++;
        snakeXhistory[moves]=snakeX;
        snakeYhistory[moves]=snakeY;

        system("cls");

        board();

        Sleep(2000/speed);
            if(kbhit()){                //zasady poruszania się
                key=getch();
                if(key==224)key+=getch();
                if(key==0)key-=getch();

                if(key==up && (direct=='l' || direct=='r')) direct='u';
                if(key==down && (direct=='l' || direct=='r')) direct='d';
                if(key==left && (direct=='u' || direct=='d')) direct='l';
                if(key==right && (direct=='u' || direct=='d')) direct='r';
            }

            if(direct=='u')snakeY--;
            if(direct=='d')snakeY++;
            if(direct=='r')snakeX++;
            if(direct=='l')snakeX--;


            //mechanika umierania
            if(tab[snakeX][snakeY]=='s'){
                if(leng+1==200){cout<<"You're a winner!";}
                else {cout <<"\nYou died  max length:"<< leng+1;}
                break;
            }

            wall();


            //mechanika jedzenia
            if(tab[snakeX][snakeY]=='f')
                {
                leng++;
                foodXY();
                cout<<food<<food;
                }
            else  //ogon go bye bye
                {tab[snakeXhistory[moves-leng]][snakeYhistory[moves-leng]]='v';
                cout<<"  ";}

            tab[snakeX][snakeY]='s';
            cout<<snake<<snake;

    }

            fstream history("plik.txt", ios::in | ios::out | ios::app);
            fstream tempFile("temp.txt", ios::out | ios::binary);

            if (tempFile){
                          if(leng+1==200){tempFile<<"Score = you got a win!\n"; }
                            else{tempFile << "Score = "<< leng+1<<"\n";}
                       }
            tempFile;
            history.seekg(0);
            tempFile << history.rdbuf();

            history.close();
            tempFile.close();

            remove("plik.txt");
            rename("temp.txt", "plik.txt");

    getch();
    return 0;
}
